
package estacionamiento;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Parking parking = new Parking("Parking Centro", 10);
        Scanner scanner = new Scanner(System.in);

        int choice = 0;

        do {
            try {
                // Mostrar opciones del menú
                System.out.println("Menú de opciones:");
                System.out.println("1) Entrada de coche");
                System.out.println("2) Salida de coche");
                System.out.println("3) Mostrar parking");
                System.out.println("4) Salir del programa");
                System.out.print("Seleccione una opción: ");

                choice = scanner.nextInt();
                scanner.nextLine();  // Consumir el carácter de nueva línea

                switch (choice) {
                    case 1:
                        // Entrada de un auto
                        handleEntradaCoche(parking, scanner);
                        break;
                    case 2:
                        // Salida de un auto 
                        handleSalidaCoche(parking, scanner);
                        break;
                    case 3:
                        // Mostrar detalles del estacionamiento
                        System.out.println(parking);
                        break;
                    case 4:
                        //Salir del programa 
                        System.out.println("Saliendo del programa. ¡Hasta luego!");
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Error: Entrada no válida. Por favor, introduzca un número.");
                scanner.nextLine();  // Clear the invalid input
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }

        } while (choice != 4);
    }

    private static void handleEntradaCoche(Parking parking, Scanner scanner) {
        try {
            System.out.print("Introduzca la matrícula del coche: ");
            String matricula = scanner.nextLine();

            System.out.print("Introduzca la plaza donde se colocará el coche: ");
            int plaza = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            parking.entrada(matricula, plaza);

            System.out.println("Entrada realizada con éxito.");
            System.out.println("Plazas totales: " + parking.getPlazasTotales());
            System.out.println("Plazas ocupadas: " + parking.getPlazasOcupadas());
            System.out.println("Plazas libres: " + parking.getPlazasLibres());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void handleSalidaCoche(Parking parking, Scanner scanner) {
        try {
            System.out.print("Introduzca la matrícula del coche que sale: ");
            String matricula = scanner.nextLine();

            int plazaLiberada = parking.salida(matricula);

            System.out.println("Salida realizada con éxito.");
            System.out.println("Plaza liberada: " + plazaLiberada);
            System.out.println("Plazas totales: " + parking.getPlazasTotales());
            System.out.println("Plazas ocupadas: " + parking.getPlazasOcupadas());
            System.out.println("Plazas libres: " + parking.getPlazasLibres());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
   