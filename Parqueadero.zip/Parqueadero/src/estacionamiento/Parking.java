
package estacionamiento;

import java.util.ArrayList;

public class Parking {
    private ArrayList<String> matriculas;  // Representa los diferentes lugares de estacionamiento y sus respectivas matrículas.
    private String nombre;  // Representa el nombre del aparcamiento.

    public Parking(String nombre, int numPlazas) {
        this.nombre = nombre;
        this.matriculas = new ArrayList<>(numPlazas);

        // Inicialice cada posición a nula, lo que indica un lugar vacío
        for (int i = 0; i < numPlazas; i++) {
            matriculas.add(null);
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void entrada(String matricula, int plaza) throws Exception {
        // Verificar matricula inválida
        if (matricula == null || matricula.length() < 4) {
            throw new Exception("Matrícula incorrecta");
        }

        // Verificar plaza no válida
        if (plaza < 0 || plaza >= matriculas.size()) {
            throw new Exception("Plaza no válida");
        }

        // Comprueba si la plaza ya está ocupada.
        if (matriculas.get(plaza) != null) {
            throw new Exception("Plaza ocupada");
        }

        // Comprueba si la matrícula ya existe en el parking.
        if (matriculas.contains(matricula)) {
            throw new Exception("Matrícula repetida");
        }

        // Estaciona el auto agregando la matrícula a la plaza especificada.
        matriculas.set(plaza, matricula);
    }

    public int salida(String matricula) throws Exception {
        // Comprueba si existe la matrícula en el aparcamiento.
        if (!matriculas.contains(matricula)) {
            throw new Exception("Matrícula no existente");
        }

        // Encuentra la plaza donde está aparcado el coche y retira la matrícula.
        int plazaLiberada = matriculas.indexOf(matricula);
        matriculas.set(plazaLiberada, null);

        // Devolver el número de plaza que fue liberado. 
        return plazaLiberada;
    }

    public int getPlazasTotales() {
        return matriculas.size();
    }

    public int getPlazasOcupadas() {
        int ocupadas = 0;
        for (String matricula : matriculas) {
            if (matricula != null) {
                ocupadas++;
            }
        }
        return ocupadas;
    }

    public int getPlazasLibres() {
        return matriculas.size() - getPlazasOcupadas();
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("Parking ").append(nombre).append("\n");

        for (int i = 0; i < matriculas.size(); i++) {
            result.append("Plaza ").append(i).append(": ");
            if (matriculas.get(i) == null) {
                result.append("(vacía)");
            } else {
                result.append(matriculas.get(i));
            }
            result.append("\n");
        }

        return result.toString();
    }
}
